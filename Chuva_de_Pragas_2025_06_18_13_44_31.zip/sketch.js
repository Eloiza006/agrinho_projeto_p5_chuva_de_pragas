function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let plantas = [];
let agua = 100;
let pragas = [];
let tempo = 0; // Contador de tempo
let pontos = 0;
let tempoEntrePragas = 2000; // Intervalo entre o surgimento das pragas (em milissegundos)

class Planta {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.crescimento = 0;
    this.regada = false;
    this.maduros = false;
    this.tamanhoMaximo = 50;
  }

  crescer() {
    if (this.crescimento < this.tamanhoMaximo) {
      this.crescimento += 0.1;
    }
    if (this.crescimento >= this.tamanhoMaximo) {
      this.maduros = true;
    }
  }

  mostrar() {
    fill(34, 139, 34);
    ellipse(
      this.x,
      this.y - this.crescimento / 2,
      this.crescimento,
      this.crescimento
    );
    fill(139, 69, 19);
    rect(this.x - 5, this.y, 10, this.crescimento);
  }

  regar() {
    if (agua > 0 && this.crescimento < this.tamanhoMaximo) {
      this.crescimento += 2;
      agua -= 5;
    }
  }

  aplicarPesticida() {
    if (this.regada) {
      this.crescimento += 3;
      pragas = pragas.filter(
        (praga) => dist(this.x, this.y, praga.x, praga.y) > 30
      );
    }
  }

  verificaPragas() {
    for (let i = 0; i < pragas.length; i++) {
      let d = dist(this.x, this.y, pragas[i].x, pragas[i].y);
      if (d < 20) {
        return true; // Tem praga próxima
      }
    }
    return false;
  }
}

class Praga {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.velocidade = random(1, 3); // Velocidade da queda
  }

  mover() {
    this.y += this.velocidade; // Movimento para baixo
    if (this.y > height) {
      // Se a praga cair para fora da tela, ela "desaparece"
      this.y = 0;
      this.x = random(width);
    }
  }

  mostrar() {
    fill(255, 0, 0); // Cor das pragas (vermelho)
    ellipse(this.x, this.y, 15, 15); // Representação das pragas
  }
}

function setup() {
  createCanvas(600, 400);
  setInterval(criarPraga, tempoEntrePragas); // Função para criar pragas em intervalos
}

function draw() {
  background(200, 255, 255); // Cor de fundo

  tempo++;

  // Exibir pontos e água disponível
  fill(0);
  textSize(20);
  text("Pontos: " + pontos, 20, 30);
  text("Água: " + agua, 20, 60);

  // Crescimento e exibição das plantas
  for (let i = 0; i < plantas.length; i++) {
    plantas[i].crescer();
    plantas[i].mostrar();

    if (plantas[i].verificaPragas()) {
      text("PRAGA!", plantas[i].x, plantas[i].y - 20); // Alerta de praga perto da planta
    }

    if (plantas[i].maduros) {
      pontos += 10; // Ganha pontos pela colheita
      plantas.splice(i, 1); // Remove a planta quando colhida
    }
  }

  // Mostrar pragas
  for (let i = 0; i < pragas.length; i++) {
    pragas[i].mover();
    pragas[i].mostrar();
  }

  // Chuva forte (acelerar o crescimento das plantas)
  if (tempo % 100 === 0) {
    if (random() < 0.2) {
      for (let i = 0; i < plantas.length; i++) {
        plantas[i].crescimento += 1;
      }
    }
  }
}

function mousePressed() {
  // Criar uma planta ao clicar no campo
  plantas.push(new Planta(mouseX, mouseY));
}

function keyPressed() {
  if (key === " ") {
    // Regar todas as plantas ao pressionar a barra de espaço
    for (let i = 0; i < plantas.length; i++) {
      plantas[i].regar();
    }
  }

  if (key === "P" || key === "p") {
    // Aplicar pesticida ao pressionar 'P'
    for (let i = 0; i < plantas.length; i++) {
      plantas[i].aplicarPesticida();
    }
  }
}

function criarPraga() {
  // Cria uma praga com uma chance rara de aparecer
  if (random() < 0.3) {
    pragas.push(new Praga(random(width), 0)); // As pragas começam da parte superior da tela
  }
}
